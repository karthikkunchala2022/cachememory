LAB 6:
this  is a c programe for cache simultation .
instruct.txt and trace.txt should be in the same folder as in lab6.c
COMPILATION:
gcc lab6.c
Karthik Kunchala
cs22btech11034
